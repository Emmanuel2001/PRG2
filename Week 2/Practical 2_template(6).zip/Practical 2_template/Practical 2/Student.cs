﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practical_2
{
    class Student
    {
        //Question 1
        //Complete the missing attributes & Properties
        
        private string phone;

        public string Phone
        {
            get { return phone; }
            set { phone = value; }
        }

        private DateTime dateofBirth;

        public DateTime DateofBirth
        {
            get { return dateofBirth; }
            set { dateofBirth = value; }
        }
            
        public Student(string hp, DateTime dob)
        {
            Phone = hp;
            DateofBirth = dob;

        }

    }
}

